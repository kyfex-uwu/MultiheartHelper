local trigger = {}


trigger.name = "MultiheartHelper/RemoveEntities"
trigger.placements = {
    name = "removeEntities",
    data = {
        entityName = ""
    }
}


return trigger