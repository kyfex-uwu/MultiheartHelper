local e = {
    name = "MultiheartHelper/LogArea",
    fillColor = "#75bdbf88",
    borderColor = "#75bdbf",
    placements = {
        name = "default",
        data = {
            width = 8,
            height = 8,
            log = "",
            terminalDialog = "",
            terminalParameters = ""
        }
    }
}

return e