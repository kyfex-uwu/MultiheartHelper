local e = {
    name = "MultiheartHelper/InventoryUIController",
    placements = {
        name = "default",
        data = {
        }
    }
}

return e