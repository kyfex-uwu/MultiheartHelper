local e = {
    name = "MultiheartHelper/InventoryUIController",
    placements = {
        name = "default",
        data = {
            UIColor = "87e3e5",
            tabs = "Misc"
        }
    },
    fieldInformation = {
        UIColor = {
            fieldType = "color"
        }
    }
}

return e