local credits = {
    name = "MultiheartHelper/Credits",
    depth = 0,
    placements = {
        name = "credits",
        data = {
            dialogKey = "",
            alignment = 0.5,
            scale = 1,
            scrollTime = 60
        }
    },
}

return credits