local e = {
    name = "MultiheartHelper/FlagOnItemController",
    placements = {
        name = "default",
        data = {
            itemName = "",
            flag = "",
            invert = false
        }
    },
    texture = "loenn/MultiheartHelper/flagOnItemController"
}

return e